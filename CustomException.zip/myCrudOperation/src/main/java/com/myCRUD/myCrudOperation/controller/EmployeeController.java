package com.myCRUD.myCrudOperation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.myCRUD.myCrudOperation.entity.Employee;
import com.myCRUD.myCrudOperation.exception.BuisnessException;
import com.myCRUD.myCrudOperation.exception.CollectorException;
import com.myCRUD.myCrudOperation.repo.EmployeeRepo;
import com.myCRUD.myCrudOperation.service.EmployeeService;

@RestController
@RequestMapping("/code")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeServiceInterface;
	
	@PostMapping("/save")
	public ResponseEntity<?> addEmployee(@RequestBody Employee employee ){
		try {
			Employee employeeSaved = employeeServiceInterface.addEmployee(employee);
			return new ResponseEntity<Employee>(employeeSaved, HttpStatus.CREATED);
			
		} catch (BuisnessException e) {
			CollectorException ce = new CollectorException(e.getErrorCode(), e.getErrorMessage());
			return new ResponseEntity<CollectorException>(ce, HttpStatus.BAD_REQUEST);
		}
		catch (Exception e) {
			CollectorException ce = new CollectorException("611", "Something went wrong");
			return new ResponseEntity<CollectorException>(ce, HttpStatus.BAD_REQUEST);
		}
		
		
		
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<Employee>> getEmployees(){
		List<Employee> listOfEmployees = employeeServiceInterface.getEmployees();
		return new ResponseEntity<List<Employee>>(listOfEmployees, HttpStatus.OK);
	}
	
	@GetMapping("/emp/{empID}")
	public ResponseEntity<?> getEmpByID(@PathVariable("empID") Long empidL){
		try {
			Employee employeeById = employeeServiceInterface.getEmpByID(empidL);
			return new ResponseEntity<Employee>(employeeById, HttpStatus.OK);
		} catch (BuisnessException e) {
			CollectorException ce = new CollectorException(e.getErrorCode(), e.getErrorMessage());
			return new ResponseEntity<CollectorException>(ce, HttpStatus.BAD_REQUEST);
		}
		catch (Exception e) {
			CollectorException ce = new CollectorException("612", "Something went wrong");
			return new ResponseEntity<CollectorException>(ce, HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@DeleteMapping("/delete/{empID}")
	public ResponseEntity<Employee> deleteEmpByID(@PathVariable("empID") Long empidL){
		 employeeServiceInterface.deleteEmpByID(empidL);
		return new ResponseEntity<Employee> (HttpStatus.ACCEPTED);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee ){
		Employee employeeSaved = employeeServiceInterface.addEmployee(employee);
		return new ResponseEntity<Employee>(employeeSaved, HttpStatus.CREATED);
		
	}

}

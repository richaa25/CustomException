package com.myCRUD.myCrudOperation.service;

import java.util.List;

import com.myCRUD.myCrudOperation.entity.Employee;

public interface EmployeeService {

	public Employee addEmployee(Employee employee);

	public List<Employee> getEmployees();

	public Employee getEmpByID(Long empidL);

	public void deleteEmpByID(Long empidL);

}

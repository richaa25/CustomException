package com.myCRUD.myCrudOperation.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myCRUD.myCrudOperation.entity.Employee;
import com.myCRUD.myCrudOperation.exception.BuisnessException;
import com.myCRUD.myCrudOperation.repo.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	EmployeeRepo employeeRepo;
	
	@Override
	public Employee addEmployee(Employee employee) {
		if(employee.getName().isEmpty() || employee.getName().length() == 0) {
			throw new BuisnessException("601", "Name is blank");
		}
		try {
			Employee savedEmployee = employeeRepo.save(employee);
			return savedEmployee;
			
		} catch (IllegalArgumentException e) {
			throw new BuisnessException("602", "employee is empty" + e.getMessage());
		}
		catch (Exception e) {
			throw new BuisnessException("603", "Something went wrong in the service layer" + e.getMessage());
		}
		
	}
	
	@Override
	public List<Employee> getEmployees(){
		List<Employee> empList = null;
		try {
			empList = employeeRepo.findAll();
			
		} catch (Exception e) {
			throw new BuisnessException("605", "Something went wrong with the Service Layer" + e.getMessage());
		}
		if(empList.isEmpty())
			throw new BuisnessException("604", "List is completely empty!");
 		return empList;
		
		
		}
	
	public Employee getEmpByID(Long empidL) {
		try {
			return employeeRepo.findById(empidL).get();
		} catch (IllegalArgumentException e) {
			throw new BuisnessException("606", "Give an ID, ID is null");
		}
		catch (NoSuchElementException e) {
			throw new BuisnessException("607", "Id doesn't exist in DB ");
		}
		
	}
	
	public void deleteEmpByID(Long empidL) {
		try {
			employeeRepo.deleteById(empidL);
		} catch (IllegalArgumentException e) {
			throw new BuisnessException("608" , "Give an ID, ID is null");
		}
		
	}



}
